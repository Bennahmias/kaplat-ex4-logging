from flask import Flask, request, jsonify
import logging
import os
from datetime import datetime

app = Flask(__name__)

# Create logs file
if not os.path.exists('logs'):
    os.makedirs('logs')

# Custom formatter to include milliseconds
class CustomFormatter(logging.Formatter):
    def formatTime(self, record, datefmt=None):
        dt = datetime.fromtimestamp(record.created)
        if datefmt:
            s = dt.strftime(datefmt)
        else:
            t = dt.strftime("%d-%m-%Y %H:%M:%S")
            s = "%s.%03d" % (t, record.msecs)
        return s

# Configure loggers
request_logger = logging.getLogger('request-logger')
books_logger = logging.getLogger('books-logger')

request_logger.setLevel(logging.INFO)
books_logger.setLevel(logging.INFO)

request_handler = logging.FileHandler('logs/requests.log')
books_handler = logging.FileHandler('logs/books.log')
console_handler = logging.StreamHandler()

formatter = CustomFormatter('%(asctime)s %(levelname)s: %(message)s')
request_handler.setFormatter(formatter)
books_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

request_logger.addHandler(request_handler)
request_logger.addHandler(console_handler)
books_logger.addHandler(books_handler)

# Global request counter
request_counter = 0

# Helper function to log messages with the request number
def log_with_request_number(logger, level, message, request_num):
    message_with_request_num = f"{message} | request #{request_num}"
    if level == 'info':
        logger.info(message_with_request_num)
    elif level == 'debug':
        logger.debug(message_with_request_num)
    elif level == 'error':
        logger.error(message_with_request_num)

# Class for books
class Book:
    counter = 1

    def __init__(self, Title, Author, Print_Year, Price, Genre):
        self.id = Book.counter
        self.title = Title
        self.author = Author
        self.print_Year = Print_Year
        self.price = Price
        self.genre = Genre
        Book.counter += 1

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'author': self.author,
            'price': self.price,
            'year': self.print_Year,
            'genres': self.genre
        }

Genre = ["SCI_FI", "NOVEL", "HISTORY", "MANGA", "ROMANCE", "PROFESSIONAL"]
# create list of books
books = []

# 1 request
@app.route('/books/health', methods=['GET'])
def health():
    global request_counter
    request_counter += 1
    start_time = datetime.now()
    log_with_request_number(request_logger, 'info', f"Incoming request | #{request_counter}"
                                                    f" | resource: /books/health | HTTP Verb GET", request_counter)
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() * 1000
    log_with_request_number(request_logger, 'debug', f"request #{request_counter} duration: {duration:.2f}ms", request_counter)

    return "OK", 200

# 2 request
@app.route('/book', methods=['POST'])
def create_book():
    global request_counter
    request_counter += 1
    start_time = datetime.now()
    log_with_request_number(request_logger, 'info', f"Incoming request | #{request_counter} | resource: /book | HTTP Verb POST", request_counter)

    data = request.get_json()
    title = data['title']
    author = data['author']
    year = data['year']
    price = data['price']
    genres = data['genres']

    if any(book.title.lower() == title.lower() for book in books):
        error_message = f"Error: Book with the title [{title}] already exists in the system"
        log_with_request_number(books_logger, 'error', error_message, request_counter)
        return jsonify(errorMessage=error_message), 409

    if not (1940 <= year <= 2100):
        error_message = f"Error: Can’t create new Book that its year [{year}] is not in the accepted range [1940 -> 2100]"
        log_with_request_number(books_logger, 'error', error_message, request_counter)
        return jsonify(errorMessage=error_message), 409

    if price <= 0:
        error_message = f"Error: Can’t create new Book with negative price"
        log_with_request_number(books_logger, 'error', error_message, request_counter)
        return jsonify(errorMessage=error_message), 409

    new_book = Book(title, author, year, price, genres)
    log_with_request_number(books_logger, 'info', f"Creating new Book with Title [{title}]", request_counter)
    log_with_request_number(books_logger, 'debug', f"Currently there are {len(books)} Books in the system. New Book will be assigned with id {new_book.id}", request_counter)

    books.append(new_book)

    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() * 1000
    log_with_request_number(request_logger, 'debug', f"request #{request_counter} duration: {duration:.2f}ms", request_counter)

    return jsonify(result=new_book.id), 200

# 3 request
@app.route('/books/total', methods=['GET'])
def get_total_books():
    global request_counter
    request_counter += 1
    start_time = datetime.now()
    log_with_request_number(request_logger, 'info', f"Incoming request | #{request_counter} | resource: /books/total | HTTP Verb GET", request_counter)

    author = request.args.get('author', '').lower()
    price_bigger_than = request.args.get('price-bigger-than', '')
    price_less_than = request.args.get('price-less-than', '')
    year_bigger_than = request.args.get('year-bigger-than', '')
    year_less_than = request.args.get('year-less-than', '')
    genres = request.args.get('genres', '').upper().split(',')

    if genres != ['']:
        for genre in genres:
            if genre not in Genre:
                return jsonify({}), 400

    filtered_books = filter_books(author, price_bigger_than, price_less_than, year_bigger_than, year_less_than, genres)
    total_books = len(filtered_books)
    log_with_request_number(books_logger, 'info', f"Total Books found for requested filters is {total_books}", request_counter)

    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() * 1000
    log_with_request_number(request_logger, 'debug', f"request #{request_counter} duration: {duration:.2f}ms", request_counter)

    return jsonify(result=total_books), 200

# 4 request
@app.route('/books', methods=['GET'])
def get_books_data():
    global request_counter
    request_counter += 1
    start_time = datetime.now()
    log_with_request_number(request_logger, 'info', f"Incoming request | #{request_counter} | resource: /books | HTTP Verb GET", request_counter)

    author = request.args.get('author', '').lower()
    price_bigger_than = request.args.get('price-bigger-than', '')
    price_less_than = request.args.get('price-less-than', '')
    year_bigger_than = request.args.get('year-bigger-than', '')
    year_less_than = request.args.get('year-less-than', '')
    genres = request.args.get('genres', '').upper().split(',')

    if genres != ['']:
        for genre in genres:
            if genre not in Genre:
                return jsonify({}), 400

    filtered_books = filter_books(author, price_bigger_than, price_less_than, year_bigger_than, year_less_than, genres)
    total_books = len(filtered_books)
    log_with_request_number(books_logger, 'info', f"Total Books found for requested filters is {total_books}", request_counter)

    filtered_books = sorted(filtered_books, key=lambda book: book.title.lower())
    result = [book.to_dict() for book in filtered_books]

    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() * 1000
    log_with_request_number(request_logger, 'debug', f"request #{request_counter} duration: {duration:.2f}ms", request_counter)

    return jsonify({"result": result}), 200


# 5 request
@app.route('/book', methods=['GET'])
def get_single_book_data():
    global request_counter
    request_counter += 1
    start_time = datetime.now()
    log_with_request_number(request_logger, 'info', f"Incoming request | #{request_counter} | resource: /book | HTTP Verb GET", request_counter)

    book_id = request.args.get('id', type=int)

    for book in books:
        if int(book_id) == int(book.id):
            log_with_request_number(books_logger, 'debug', f"Fetching book id {book_id} details", request_counter)
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds() * 1000
            log_with_request_number(request_logger, 'debug', f"request #{request_counter} duration: {duration:.2f}ms", request_counter)

            return jsonify({"result": book.to_dict()}), 200

    error_message = f"Error: no such Book with id {book_id}"
    log_with_request_number(request_logger, 'error', error_message, request_counter)

    return jsonify({'errorMessage': error_message}), 404

# 6 request
@app.route('/book', methods=['PUT'])
def update_book_price():
    global request_counter
    request_counter += 1
    start_time = datetime.now()
    log_with_request_number(request_logger, 'info', f"Incoming request | #{request_counter} | resource: /book | HTTP Verb PUT", request_counter)

    book_id = request.args.get('id')
    new_price = request.args.get('price')

    book_to_update = None
    for book in books:
        if str(book_id) == str(book.id):
            book_to_update = book
            break

    if book_to_update is None:
        error_message = f"Error: no such Book with id {book_id}"
        log_with_request_number(request_logger, 'error', error_message, request_counter)
        return jsonify(errorMessage=error_message), 404

    new_price = int(new_price)
    if new_price <= 0:
        error_message = f"Error: price update for book [{book_id}] must be a positive integer"
        log_with_request_number(request_logger, 'error', error_message, request_counter)
        return jsonify(errorMessage=error_message), 409

    old_price = book_to_update.price
    book_to_update.price = new_price
    log_with_request_number(books_logger, 'info', f"Update Book id [{book_id}] price to {new_price}", request_counter)
    log_with_request_number(books_logger, 'debug', f"Book [{book_to_update.title}] price change: {old_price} --> {new_price}", request_counter)

    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() * 1000
    log_with_request_number(request_logger, 'debug', f"request #{request_counter} duration: {duration:.2f}ms", request_counter)

    return jsonify(result=old_price), 200

# 7 request
@app.route('/book', methods=['DELETE'])
def delete_book():
    global request_counter
    request_counter += 1
    start_time = datetime.now()
    log_with_request_number(request_logger, 'info', f"Incoming request | #{request_counter} | resource: /book | HTTP Verb DELETE", request_counter)

    book_id = request.args.get('id')

    book_to_delete = None
    for book in books:
        if str(book_id) == str(book.id):
            book_to_delete = book
            break

    if book_to_delete is None:
        error_message = f"Error: no such Book with id {book_id}"
        log_with_request_number(request_logger, 'error', error_message, request_counter)
        return jsonify(errorMessage=error_message), 404

    books.remove(book_to_delete)
    log_with_request_number(books_logger, 'info', f"Removing book [{book_to_delete.title}]", request_counter)
    log_with_request_number(books_logger, 'debug', f"After removing book [{book_to_delete.title}] id: [{book_id}] there are {len(books)} books in the system", request_counter)

    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() * 1000
    log_with_request_number(request_logger, 'debug', f"request #{request_counter} duration: {duration:.2f}ms", request_counter)

    return jsonify(result=len(books)), 200

def filter_books(author, price_bigger_than, price_less_than, year_bigger_than, year_less_than, genres):
    filtered_books = books

    if author:
        filtered_books = [book for book in filtered_books if book.author.lower() == author]
    if price_bigger_than:
        filtered_books = [book for book in filtered_books if book.price >= int(price_bigger_than)]
    if price_less_than:
        filtered_books = [book for book in filtered_books if book.price <= int(price_less_than)]
    if year_bigger_than:
        filtered_books = [book for book in filtered_books if book.print_Year >= int(year_bigger_than)]
    if year_less_than:
        filtered_books = [book for book in filtered_books if book.print_Year <= int(year_less_than)]
    if genres != ['']:
        filtered_books = [book for book in filtered_books if any(genre in book.genre for genre in genres)]
    return filtered_books

# 8 request
@app.route('/logs/level', methods=['GET'])
def get_log_level():
    global request_counter
    request_counter += 1
    start_time = datetime.now()
    log_with_request_number(request_logger, 'info', f"Incoming request | #{request_counter} | resource: /logs/level | HTTP Verb GET", request_counter)

    logger_name = request.args.get('logger-name')
    if logger_name == 'request-logger':
        logger = request_logger
    elif logger_name == 'books-logger':
        logger = books_logger
    else:
        return "Invalid logger name", 400

    level = logging.getLevelName(logger.level)
    end_time = datetime.now()

    duration = (end_time - start_time).total_seconds() * 1000
    log_with_request_number(request_logger, 'debug', f"request #{request_counter} duration: {duration:.2f}ms", request_counter)
    return level, 200

# 9 request
@app.route('/logs/level', methods=['PUT'])
def set_log_level():
    global request_counter
    request_counter += 1
    start_time = datetime.now()
    log_with_request_number(request_logger, 'info', f"Incoming request | #{request_counter} | resource: /logs/level | HTTP Verb PUT", request_counter)
    logger_name = request.args.get('logger-name')
    logger_level = request.args.get('logger-level').upper()

    if logger_level not in ['ERROR', 'INFO', 'DEBUG']:
        return "Invalid log level", 400

    if logger_name == 'request-logger':
        logger = request_logger
    elif logger_name == 'books-logger':
        logger = books_logger
    else:
        return "Invalid logger name", 400

    level = getattr(logging, logger_level, None)
    logger.setLevel(level)
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() * 1000
    log_with_request_number(request_logger, 'debug', f"request #{request_counter} duration: {duration:.2f}ms", request_counter)
    return logger_level, 200

if __name__ == '__main__':
    app.run(host='localhost', port=8574)
